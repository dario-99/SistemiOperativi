COMANDI: 
    make: per compilare e linkare il codice
    ./main: per eseguire il programma
    clean: remove .o e main
