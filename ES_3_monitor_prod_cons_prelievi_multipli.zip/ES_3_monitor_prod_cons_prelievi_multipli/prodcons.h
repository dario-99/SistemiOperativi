#ifndef _PRODCONS_H_
#define _PRODCONS_H_

#include "monitor_hoare.h"

#define DIM 10

typedef struct {
    long vettore[DIM];

    /* TBD: Definire il Monitor e le altre variabili per la sincronizzazione */
    
} ProdCons;

/* TBD: Definire delle macro per identificare le variabili condition */

void inizializza(ProdCons * p);
void consuma(ProdCons * p);
void produci(ProdCons * p, int val);
void rimuovi(ProdCons * p);

#endif
